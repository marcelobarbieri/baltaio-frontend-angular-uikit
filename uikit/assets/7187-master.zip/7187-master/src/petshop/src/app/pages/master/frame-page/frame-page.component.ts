import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frame-page',
  templateUrl: './frame-page.component.html',
  styleUrls: ['./frame-page.component.css']
})
export class FramePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
