import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pets-page',
  templateUrl: './pets-page.component.html',
  styleUrls: ['./pets-page.component.css']
})
export class PetsPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
